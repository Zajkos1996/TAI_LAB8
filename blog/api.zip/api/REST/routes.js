import postEndpoint from './post.endpoint';

const routes = (router) => {
  postEndpoint(router);
};

export default routes;
